//runs once on active tab
console.log("content")
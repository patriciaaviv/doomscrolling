
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        console.log("loading completed.")
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ["./content.js"]
        })
            .then(() => {
                console.log("Injected Foreground JS.");
            })
            .catch(err => console.log(err));
    }
});